from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import networkx as nx
import json
import csv
import io
from collections import defaultdict, Counter
import pandas as pd

app = Flask(__name__)
CORS(app)

# Global graph to store our social media network
G = nx.DiGraph()

# Store additional node and edge attributes
node_attributes = {}
edge_attributes = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_interaction', methods=['POST'])
def add_interaction():
    try:
        data = request.get_json()
        source = data.get('source', '').strip()
        target = data.get('target', '').strip()
        relationship = data.get('relationship', '').strip()
        weight = float(data.get('weight', 1.0))
        
        if not source or not target or not relationship:
            return jsonify({'error': 'Source, target, and relationship are required'}), 400
        
        # Add nodes if they don't exist
        if source not in G:
            G.add_node(source)
            node_attributes[source] = {
                'type': 'user',
                'follower_count': 0,
                'engagement_score': 0,
                'posts': []
            }
        
        if target not in G:
            G.add_node(target)
            node_attributes[target] = {
                'type': 'user',
                'follower_count': 0,
                'engagement_score': 0,
                'posts': []
            }
        
        # Add or update edge
        if G.has_edge(source, target):
            G[source][target]['weight'] += weight
        else:
            G.add_edge(source, target, weight=weight, relationship=relationship)
        
        return jsonify({'message': 'Interaction added successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/add_user', methods=['POST'])
def add_user():
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        follower_count = int(data.get('follower_count', 0))
        engagement_score = float(data.get('engagement_score', 0))
        
        if not username:
            return jsonify({'error': 'Username is required'}), 400
        
        # Add node
        G.add_node(username)
        node_attributes[username] = {
            'type': 'user',
            'follower_count': follower_count,
            'engagement_score': engagement_score,
            'posts': []
        }
        
        return jsonify({'message': 'User added successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/add_post', methods=['POST'])
def add_post():
    try:
        data = request.get_json()
        post_id = data.get('post_id', '').strip()
        author = data.get('author', '').strip()
        content = data.get('content', '')
        likes = int(data.get('likes', 0))
        shares = int(data.get('shares', 0))
        
        if not post_id or not author:
            return jsonify({'error': 'Post ID and author are required'}), 400
        
        # Add post as a node
        G.add_node(post_id)
        node_attributes[post_id] = {
            'type': 'post',
            'content': content,
            'likes': likes,
            'shares': shares,
            'author': author
        }
        
        # Add edge from author to post
        G.add_edge(author, post_id, weight=1, relationship='created')
        
        # Add author if not exists
        if author not in node_attributes:
            node_attributes[author] = {
                'type': 'user',
                'follower_count': 0,
                'engagement_score': 0,
                'posts': []
            }
        
        node_attributes[author]['posts'].append(post_id)
        
        return jsonify({'message': 'Post added successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500



@app.route('/upload_file', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        filename = file.filename.lower()
        
        if filename.endswith('.csv'):
            return process_csv_file(file)
        elif filename.endswith('.json'):
            return process_json_file(file)
        else:
            return jsonify({'error': 'Only CSV and JSON files are supported'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def process_csv_file(file):
    try:
        # Read CSV file
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        interactions_added = 0
        posts_added = 0
        processed_posts = set()  # To avoid duplicate posts
        
        for row in csv_input:
            # Extract data using new CSV structure
            source_entity = row.get('source_entity', '').strip()
            source_type = row.get('source_type', '').strip()
            relationship_type = row.get('relationship_type', '').strip()
            target_entity = row.get('target_entity', '').strip()
            target_type = row.get('target_type', '').strip()
            source_handle = row.get('source_handle', '').strip()
            target_handle = row.get('target_handle', '').strip()
            content = row.get('content', '').strip()
            interaction_weight = float(row.get('interaction_weight', 1.0))
            
            # Handle post creation
            if relationship_type == 'created' and source_type == 'USER' and target_type == 'POST':
                post_id = target_entity
                post_author = source_handle
                
                # Create unique identifier for post to avoid duplicates
                post_key = f"{post_id}_{post_author}"
                
                if post_key not in processed_posts:
                    # Add post author as node if not exists
                    if post_author not in G:
                        G.add_node(post_author)
                        node_attributes[post_author] = {
                            'type': 'user',
                            'follower_count': int(row.get('source_follower_count', 0)),
                            'engagement_score': float(row.get('source_engagement_score', 0.0)),
                            'posts': []
                        }
                    
                    # Create post object
                    post_data = {
                        'id': post_id,
                        'author': post_author,
                        'content': content,
                        'likes': 0,  # Initial likes count
                        'shares': 0,  # Initial shares count
                        'timestamp': row.get('interaction_timestamp', ''),
                        'hashtags': row.get('hashtags', '').split(',') if row.get('hashtags') else []
                    }
                    
                    # Add post to author's posts list
                    if post_author in node_attributes:
                        # node_attributes[post_author]['posts'].append(post_data)
                         node_attributes[post_author]['posts'].append(post_id)
                    
                    # Store post globally
                    if 'posts' not in globals():
                        global posts
                        posts = {}
                    posts[post_id] = post_data
                    
                    processed_posts.add(post_key)
                    posts_added += 1
            
            # Handle user interactions (follows, likes, shares, mentions)
            elif source_handle and relationship_type in ['follows', 'likes', 'shares', 'mentions']:
                source = source_handle
                
                # Determine target based on relationship type
                if relationship_type == 'follows':
                    target = target_handle
                elif relationship_type in ['likes', 'shares']:
                    # For likes/shares, target is post, but we track interaction with post author
                    target = target_handle  # Post author
                    post_id = target_entity
                    
                    # Update post metrics if post exists
                    if 'posts' in globals() and post_id in posts:
                        if relationship_type == 'likes':
                            posts[post_id]['likes'] += 1
                        elif relationship_type == 'shares':
                            posts[post_id]['shares'] += 1
                elif relationship_type == 'mentions':
                    target = target_handle
                
                if source and target:
                    # Add nodes
                    for node in [source, target]:
                        if node not in G:
                            G.add_node(node)
                            # Set attributes based on whether it's source or target
                            if node == source:
                                node_attributes[node] = {
                                    'type': 'user',
                                    'follower_count': int(row.get('source_follower_count', 0)),
                                    'engagement_score': float(row.get('source_engagement_score', 0.0)),
                                    'posts': []
                                }
                            else:  # target node
                                node_attributes[node] = {
                                    'type': 'user',
                                    'follower_count': int(row.get('target_follower_count', 0)),
                                    'engagement_score': float(row.get('target_engagement_score', 0.0)),
                                    'posts': []
                                }
                    
                    # Add edge with relationship type
                    if G.has_edge(source, target):
                        # If edge exists, update weight or add multiple relationship types
                        G[source][target]['weight'] += interaction_weight
                        # Store multiple relationship types if needed
                        if 'relationships' not in G[source][target]:
                            G[source][target]['relationships'] = []
                        if relationship_type not in G[source][target]['relationships']:
                            G[source][target]['relationships'].append(relationship_type)
                    else:
                        G.add_edge(source, target, 
                                 weight=interaction_weight, 
                                 relationship=relationship_type,
                                 relationships=[relationship_type],
                                 timestamp=row.get('interaction_timestamp', ''))
                    
                    interactions_added += 1
        
        message = f'Successfully processed CSV file. Added {interactions_added} interactions'
        if posts_added > 0:
            message += f' and {posts_added} posts'
        message += '.'
        
        return jsonify({'message': message})
    
    except Exception as e:
        return jsonify({'error': f'Error processing CSV: {str(e)}'}), 500

def process_json_file(file):
    try:
        data = json.load(file)
        
        interactions_added = 0
        
        # Handle different JSON structures
        if isinstance(data, list):
            for item in data:
                if 'source' in item and 'target' in item:
                    source = item['source'].strip()
                    target = item['target'].strip()
                    relationship = item.get('relationship', 'interacts').strip()
                    weight = float(item.get('weight', 1.0))
                    
                    # Add nodes and edges
                    for node in [source, target]:
                        if node not in G:
                            G.add_node(node)
                            node_attributes[node] = {
                                'type': 'user',
                                'follower_count': item.get('follower_count', 0) if node == source else 0,
                                'engagement_score': item.get('engagement_score', 0) if node == source else 0,
                                'posts': []
                            }
                    
                    if G.has_edge(source, target):
                        G[source][target]['weight'] += weight
                    else:
                        G.add_edge(source, target, weight=weight, relationship=relationship)
                    
                    interactions_added += 1
        
        return jsonify({'message': f'Successfully processed JSON file. Added {interactions_added} interactions.'})
    
    except Exception as e:
        return jsonify({'error': f'Error processing JSON: {str(e)}'}), 500


@app.route('/get_graph_data', methods=['GET'])
def get_graph_data():
    try:
        nodes = []
        links = []
        
        # Calculate influence metrics
        pagerank = nx.pagerank(G) if len(G.nodes()) > 0 else {}
        betweenness = nx.betweenness_centrality(G) if len(G.nodes()) > 0 else {}
        
        # Prepare user nodes data
        for node in G.nodes():
            node_data = {
                'id': node,
                'type': node_attributes.get(node, {}).get('type', 'user'),
                'pagerank': pagerank.get(node, 0),
                'betweenness': betweenness.get(node, 0),
                'degree': G.degree(node)
            }
            
            # Add user-specific attributes
            if node_data['type'] == 'user':
                user_attrs = node_attributes.get(node, {})
                node_data.update({
                    'follower_count': user_attrs.get('follower_count', 0),
                    'engagement_score': user_attrs.get('engagement_score', 0),
                    'posts': user_attrs.get('posts', []),
                    'post_count': len(user_attrs.get('posts', [])),
                    'total_likes': sum(node_attributes.get(post, {}).get('likes', 0)
                            for post in user_attrs.get('posts', [])),
        'total_shares': sum(node_attributes.get(post, {}).get('shares', 0)
                             for post in user_attrs.get('posts', []))
                })
            
            nodes.append(node_data)
        
        # Add post nodes from global posts dictionary
        if 'posts' in globals() and posts:
            for post_id, post_data in posts.items():
                # Check if post node already exists
                if not any(node['id'] == post_id for node in nodes):
                    post_node = {
                        'id': post_id,
                        'type': 'post',
                        'pagerank': 0,  # Posts don't participate in PageRank
                        'betweenness': 0,
                        'degree': 0,  # Will be calculated based on interactions
                        'content': post_data.get('content', ''),
                        'likes': post_data.get('likes', 0),
                        'shares': post_data.get('shares', 0),
                        'author': post_data.get('author', ''),
                        'timestamp': post_data.get('timestamp', ''),
                        'hashtags': post_data.get('hashtags', []),
                        'post_type': 'text'
                    }
                    nodes.append(post_node)
                    
                    # Create authorship link between user and post
                    author = post_data.get('author', '')
                    if author:
                        authorship_link = {
                            'source': author,
                            'target': post_id,
                            'weight': 5.0,  # High weight for authorship
                            'relationship': 'created',
                            'relationship_type': 'created',
                            'timestamp': post_data.get('timestamp', ''),
                            'interaction_weight': 5.0
                        }
                        links.append(authorship_link)
        
        # Prepare edges data from graph (user-to-user relationships)
        for source, target, data in G.edges(data=True):
            link_data = {
                'source': source,
                'target': target,
                'weight': data.get('weight', 1),
                'relationship': data.get('relationship', 'interacts'),
                'relationship_type': data.get('relationship', 'interacts'),
                'timestamp': data.get('timestamp', ''),
                'interaction_weight': data.get('weight', 1)
            }
            
            # Add multiple relationship types if they exist
            if 'relationships' in data:
                link_data['relationships'] = data['relationships']
                link_data['relationship_types'] = data['relationships']
            
            links.append(link_data)
        
        # Add post interaction links (likes, shares) from posts data
        if 'posts' in globals() and posts:
            for post_id, post_data in posts.items():
                post_author = post_data.get('author', '')
                
                # Create like interactions (simulate based on post likes count)
                likes_count = post_data.get('likes', 0)
                if likes_count > 0:
                    # Find users who could have liked this post (excluding author)
                    potential_likers = [n for n in nodes if n['type'] == 'user' and n['id'] != post_author]
                    
                    # Create like relationships for active users
                    likers_added = 0
                    for user_node in potential_likers:
                        if (likers_added < likes_count and 
                            user_node.get('engagement_score', 0) > 5.0):  # Active users only
                            
                            like_link = {
                                'source': user_node['id'],
                                'target': post_id,
                                'weight': 1.0,
                                'relationship': 'likes',
                                'relationship_type': 'likes',
                                'timestamp': post_data.get('timestamp', ''),
                                'interaction_weight': 1.0
                            }
                            links.append(like_link)
                            likers_added += 1
                
                # Create share interactions (simulate based on post shares count)
                shares_count = post_data.get('shares', 0)
                if shares_count > 0:
                    # Find users who could have shared this post (excluding author)
                    potential_sharers = [n for n in nodes if n['type'] == 'user' and 
                                       n['id'] != post_author and 
                                       n.get('engagement_score', 0) > 7.0]  # High engagement users
                    
                    # Create share relationships
                    sharers_added = 0
                    for user_node in potential_sharers:
                        if sharers_added < shares_count:
                            share_link = {
                                'source': user_node['id'],
                                'target': post_id,
                                'weight': 2.0,  # Shares are more valuable than likes
                                'relationship': 'shares',
                                'relationship_type': 'shares',
                                'timestamp': post_data.get('timestamp', ''),
                                'interaction_weight': 2.0
                            }
                            links.append(share_link)
                            sharers_added += 1
        
        # Update post node degrees based on interactions
        for node in nodes:
            if node['type'] == 'post':
                post_id = node['id']
                # Count incoming links (likes, shares, etc.)
                incoming_links = [link for link in links if link['target'] == post_id]
                node['degree'] = len(incoming_links)
        
        # Calculate additional statistics
        user_nodes = [n for n in nodes if n['type'] == 'user']
        post_nodes = [n for n in nodes if n['type'] == 'post']
        
        # Get relationship type counts
        relationship_counts = {}
        for link in links:
            rel_type = link.get('relationship_type', 'unknown')
            relationship_counts[rel_type] = relationship_counts.get(rel_type, 0) + 1
        
        # Get top influencers (based on PageRank and follower count)
        top_influencers = sorted(user_nodes, 
                               key=lambda x: (x.get('pagerank', 0) * 0.6 + 
                                            (x.get('follower_count', 0) / 1000) * 0.4), 
                               reverse=True)[:5]
        
        # Get most engaged posts
        most_engaged_posts = sorted(post_nodes, 
                                  key=lambda x: (x.get('likes', 0) * 1 + x.get('shares', 0) * 2), 
                                  reverse=True)[:5]
        
        # Get most active users (by post count and engagement)
        most_active_users = sorted(user_nodes,
                                 key=lambda x: (x.get('post_count', 0) * 2 + 
                                              x.get('engagement_score', 0)),
                                 reverse=True)[:5]
        
        # Get hashtag analysis
        hashtag_counts = {}
        for post in post_nodes:
            for hashtag in post.get('hashtags', []):
                hashtag = hashtag.strip()
                if hashtag:
                    hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1
        
        top_hashtags = sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return jsonify({
            'nodes': nodes,
            'links': links,
            'stats': {
                'total_nodes': len(nodes),
                'total_edges': len(links),
                'total_users': len(user_nodes),
                'total_posts': len(post_nodes),
                'density': nx.density(G) if len(G.nodes()) > 1 else 0,
                'average_degree': sum(node['degree'] for node in nodes) / len(nodes) if nodes else 0,
                'total_likes': sum(post.get('likes', 0) for post in post_nodes),
                'total_shares': sum(post.get('shares', 0) for post in post_nodes),
                'relationship_counts': relationship_counts,
                'average_engagement': sum(user.get('engagement_score', 0) for user in user_nodes) / len(user_nodes) if user_nodes else 0
            },
            'insights': {
                'top_influencers': [
                    {
                        'user': user['id'],
                        'pagerank': round(user.get('pagerank', 0), 4),
                        'follower_count': user.get('follower_count', 0),
                        'engagement_score': user.get('engagement_score', 0),
                        'post_count': user.get('post_count', 0),
                        'total_likes': user.get('total_likes', 0)
                    } for user in top_influencers
                ],
                'most_engaged_posts': [
                    {
                        'post_id': post['id'],
                        'author': post.get('author', ''),
                        'content_preview': post.get('content', '')[:100] + ('...' if len(post.get('content', '')) > 100 else ''),
                        'likes': post.get('likes', 0),
                        'shares': post.get('shares', 0),
                        'total_engagement': post.get('likes', 0) + (post.get('shares', 0) * 2),
                        'hashtags': post.get('hashtags', [])[:3],  # Top 3 hashtags
                        'timestamp': post.get('timestamp', '')
                    } for post in most_engaged_posts
                ],
                'most_active_users': [
                    {
                        'user': user['id'],
                        'post_count': user.get('post_count', 0),
                        'engagement_score': user.get('engagement_score', 0),
                        'total_likes': user.get('total_likes', 0),
                        'total_shares': user.get('total_shares', 0)
                    } for user in most_active_users
                ],
                'top_hashtags': [
                    {
                        'hashtag': hashtag,
                        'count': count
                    } for hashtag, count in top_hashtags
                ],
                'network_insights': {
                    'most_followed_user': max(user_nodes, key=lambda x: x.get('follower_count', 0))['id'] if user_nodes else None,
                    'highest_engagement_user': max(user_nodes, key=lambda x: x.get('engagement_score', 0))['id'] if user_nodes else None,
                    'most_liked_post': max(post_nodes, key=lambda x: x.get('likes', 0))['id'] if post_nodes else None,
                    'most_shared_post': max(post_nodes, key=lambda x: x.get('shares', 0))['id'] if post_nodes else None
                }
            }
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Additional endpoint to get detailed post information
@app.route('/get_post_details/<post_id>', methods=['GET'])
def get_post_details(post_id):
    try:
        if 'posts' in globals() and post_id in posts:
            post_data = posts[post_id]
            
            # Get author details
            author = post_data.get('author', '')
            author_details = {}
            if author in node_attributes:
                author_details = {
                    'follower_count': node_attributes[author].get('follower_count', 0),
                    'engagement_score': node_attributes[author].get('engagement_score', 0),
                    'total_posts': len(node_attributes[author].get('posts', []))
                }
            
            # Get interactions with this post
            interactions = []
            for source, target, data in G.edges(data=True):
                if target == post_id:
                    interactions.append({
                        'user': source,
                        'relationship': data.get('relationship', 'interacted'),
                        'weight': data.get('weight', 1)
                    })
            
            return jsonify({
                'post': post_data,
                'author_details': author_details,
                'interactions': interactions,
                'engagement_metrics': {
                    'likes': post_data.get('likes', 0),
                    'shares': post_data.get('shares', 0),
                    'total_interactions': len(interactions)
                }
            })
        else:
            return jsonify({'error': 'Post not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Endpoint to get user's posts
@app.route('/get_user_posts/<username>', methods=['GET'])
def get_user_posts(username):
    try:
        if username in node_attributes:
            user_data = node_attributes[username]
            posts = user_data.get('posts', [])
            
            return jsonify({
                'user': username,
                'user_stats': {
                    'follower_count': user_data.get('follower_count', 0),
                    'engagement_score': user_data.get('engagement_score', 0),
                    'total_posts': len(posts)
                },
                'posts': posts
            })
        else:
            return jsonify({'error': 'User not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_influence_chain/<username>', methods=['GET'])
def get_influence_chain(username):
    try:
        if username not in G:
            return jsonify({'error': 'User not found'}), 404

        is_directed = G.is_directed()

        influenced_by_user = list(G.successors(username)) if is_directed else list(G.neighbors(username))
        influences_user = list(G.predecessors(username)) if is_directed else list(G.neighbors(username))

        pagerank = nx.pagerank(G) if len(G.nodes()) > 0 else {}
        top_influencers = sorted(pagerank.items(), key=lambda x: x[1], reverse=True)[:5]

        paths_to_influencers = []
        for influencer, score in top_influencers:
            if influencer != username and nx.has_path(G, username, influencer):
                try:
                    path = nx.shortest_path(G, username, influencer)
                    paths_to_influencers.append({
                        'target': influencer,
                        'path': path,
                        'path_length': len(path) - 1,
                        'influence_score': score
                    })
                except nx.NetworkXNoPath:
                    continue

        return jsonify({
            'user': username,
            'influences': influenced_by_user,
            'influenced_by': influences_user,
            'paths_to_top_influencers': paths_to_influencers,
            'direct_influence_count': len(influenced_by_user),
            'influenced_by_count': len(influences_user)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/get_mutual_connections', methods=['GET'])
def get_mutual_connections():
    try:
        user1 = request.args.get('user1', '').strip()
        user2 = request.args.get('user2', '').strip()
        
        if not user1 or not user2:
            return jsonify({'error': 'Both user1 and user2 parameters are required'}), 400
        
        if user1 not in G or user2 not in G:
            return jsonify({'error': 'One or both users not found'}), 404
        
        # Get neighbors of both users
        user1_neighbors = set(G.neighbors(user1))
        user2_neighbors = set(G.neighbors(user2))
        
        # Find mutual connections
        mutual = user1_neighbors.intersection(user2_neighbors)
        
        # Check if users are directly connected
        direct_connection = G.has_edge(user1, user2) or G.has_edge(user2, user1)
        
        # Find shortest path between users
        shortest_path = []
        path_length = 0
        if nx.has_path(G.to_undirected(), user1, user2):
            try:
                shortest_path = nx.shortest_path(G.to_undirected(), user1, user2)
                path_length = len(shortest_path) - 1
            except nx.NetworkXNoPath:
                pass
        
        return jsonify({
            'user1': user1,
            'user2': user2,
            'mutual_connections': list(mutual),
            'mutual_count': len(mutual),
            'direct_connection': direct_connection,
            'shortest_path': shortest_path,
            'path_length': path_length,
            'user1_total_connections': len(user1_neighbors),
            'user2_total_connections': len(user2_neighbors)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_top_influencers', methods=['GET'])
def get_top_influencers():
    try:
        limit = int(request.args.get('limit', 10))
        
        if len(G.nodes()) == 0:
            return jsonify({'influencers': []})
        
        pagerank = nx.pagerank(G)
        betweenness = nx.betweenness_centrality(G)
        degree = dict(G.degree())
        
        influencers = []
        for node in G.nodes():
            if node_attributes.get(node, {}).get('type', 'user') == 'user':
                influence_score = (
                    pagerank.get(node, 0) * 0.4 +
                    betweenness.get(node, 0) * 0.3 +
                    (degree.get(node, 0) / max(1, len(G.nodes()))) * 0.3
                )
                
                influencers.append({
                    'username': node,
                    'influence_score': influence_score,
                    'pagerank': pagerank.get(node, 0),
                    'betweenness': betweenness.get(node, 0),
                    'degree': degree.get(node, 0),
                    'follower_count': node_attributes.get(node, {}).get('follower_count', 0),
                    'engagement_score': node_attributes.get(node, {}).get('engagement_score', 0)
                })
        
        influencers.sort(key=lambda x: x['influence_score'], reverse=True)
        
        return jsonify({
            'influencers': influencers[:limit],
            'total_users': len([n for n in G.nodes() if node_attributes.get(n, {}).get('type', 'user') == 'user'])
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/clear_graph', methods=['POST'])
def clear_graph():
    try:
        global G, node_attributes, edge_attributes, posts

        # Clear the graph and reinitialize it to drop any lingering internal state.
        G.clear()
        G = nx.Graph()  # or nx.DiGraph(), depending on your usage

        # Completely reset the attribute dictionaries.
        node_attributes = {}
        edge_attributes = {}

        # Clear posts since they feed new nodes into the graph.
        if 'posts' in globals() and posts:
            posts.clear()
        else:
            posts = {}

        return jsonify({'message': 'Graph, attributes, and posts cleared successfully.'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5002)