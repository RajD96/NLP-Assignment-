function loadGraph() {
    fetch('/graph-data')
        .then(response => response.json())
        .then(data => drawGraph(data));
}

function drawGraph(data) {
    d3.select("#graph-container").selectAll("*").remove();

    const width = 900, height = 500;

    const svg = d3.select("#graph-container")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    const relations = [...new Set(data.edges.map(d => d.relation))];

    const defs = svg.append("defs");

    relations.forEach(relation => {
        defs.append("marker")
            .attr("id", `arrow-${relation}`)
            .attr("viewBox", "0 -5 10 10")
            .attr("refX", 28)
            .attr("refY", 0)
            .attr("markerWidth", 6)
            .attr("markerHeight", 6)
            .attr("orient", "auto")
            .append("path")
            .attr("d", "M0,-5L10,0L0,5")
            .attr("fill", getRelationColor(relation));
    });

    const color = d => {
        if (d.type === 'user') return '#2980b9';
        if (d.type === 'content') return '#e67e22';
        return '#95a5a6';
      };
      

    function getRelationColor(relation) {
        const colors = {
            'follows': '#2ecc71',
            'mentions': '#9b59b6',
            'likes': '#e74c3c'
        };
        return colors[relation] || '#7f8c8d';
    }

    const simulation = d3.forceSimulation(data.nodes)
        .force("link", d3.forceLink(data.edges).id(d => d.id).distance(160))
        .force("charge", d3.forceManyBody().strength(-400))
        .force("center", d3.forceCenter(width / 2, height / 2));

    const link = svg.append("g")
        .attr("stroke-opacity", 0.7)
        .selectAll("line")
        .data(data.edges)
        .join("line")
        .attr("stroke-width", 2)
        .attr("stroke", d => getRelationColor(d.relation))
        .attr("marker-end", d => `url(#arrow-${d.relation})`);

    const node = svg.append("g")
        .attr("stroke", "#fff")
        .attr("stroke-width", 1.5)
        .selectAll("circle")
        .data(data.nodes)
        .join("circle")
        .attr("r", d => d.size)
        .attr("fill", d => color(d))
        .style("filter", "drop-shadow(0 0 3px rgba(0,0,0,0.5))")
        .call(drag(simulation));

    node.append("title").text(d => d.id);

    const label = svg.append("g")
        .selectAll("text")
        .data(data.nodes)
        .join("text")
        .text(d => d.id)
        .attr("font-size", "14px")
        .attr("font-weight", "bold")
        .attr("fill", "#333");

    const edgeLabel = svg.append("g")
        .selectAll("text")
        .data(data.edges)
        .join("text")
        .text(d => d.relation)
        .attr("font-size", "12px")
        .attr("font-weight", "500")
        .attr("fill", "#555");

    simulation.on("tick", () => {
        link
            .attr("x1", d => d.source.x)
            .attr("y1", d => d.source.y)
            .attr("x2", d => d.target.x)
            .attr("y2", d => d.target.y);

        node
            .attr("cx", d => d.x)
            .attr("cy", d => d.y);

        label
            .attr("x", d => d.x + 12)
            .attr("y", d => d.y + 5);

        edgeLabel
            .attr("x", d => (d.source.x + d.target.x) / 2)
            .attr("y", d => (d.source.y + d.target.y) / 2);
    });
}


function drag(simulation) {
    function dragstarted(event, d) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
    }

    function dragged(event, d) {
        d.fx = event.x;
        d.fy = event.y;
    }

    function dragended(event, d) {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
    }

    return d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);
}
